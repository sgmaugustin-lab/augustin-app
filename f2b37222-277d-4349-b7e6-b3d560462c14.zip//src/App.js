import { useState } from "react";

function CommentSection({ post, onAdd }) {
  const [text, setText] = useState("");

  return (
    <div style={{ marginTop: 10 }}>
      {post.comments.map((c) => (
        <div key={c.id} style={{ fontSize: 14, marginBottom: 4 }}>
          <strong>{c.user}:</strong> {c.text}
        </div>
      ))}
      <input
        placeholder="Scrie un comentariu..."
        value={text}
        onChange={(e) => setText(e.target.value)}
        style={{
          width: "100%",
          padding: 6,
          borderRadius: 8,
          border: "none",
          marginTop: 6,
        }}
      />
      <button
        style={{ ...styles.button, marginTop: 6 }}
        onClick={() => {
          onAdd(post.id, text);
          setText("");
        }}
      >
        Comentează
      </button>
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState({
    name: "",
    avatar: "https://i.pravatar.cc/150?img=12",
  });

  const [entered, setEntered] = useState(false);

  const [posts, setPosts] = useState([]);
  const [text, setText] = useState("");
  const [image, setImage] = useState(null);

  const addPost = () => {
    if (!text && !image) return;
    setPosts([
      {
        id: Date.now(),
        text,
        image,
        likes: 0,
        comments: [],
        user,
      },
      ...posts,
    ]);
    setText("");
    setImage(null);
  };

  const likePost = (id) => {
    setPosts(
      posts.map((p) => (p.id === id ? { ...p, likes: p.likes + 1 } : p))
    );
  };

  const addComment = (postId, text) => {
    if (!text.trim()) return;
    setPosts(
      posts.map((p) =>
        p.id === postId
          ? {
              ...p,
              comments: [
                ...p.comments,
                { id: Date.now(), user: user.name, text },
              ],
            }
          : p
      )
    );
  };

  const handleImage = (e) => {
    if (!e.target.files || !e.target.files[0]) return;
    const reader = new FileReader();
    reader.onloadend = () => setImage(reader.result);
    reader.readAsDataURL(e.target.files[0]);
  };

  if (!entered) {
    return (
      <div style={styles.page}>
        <div style={styles.card}>
          <h2>Puneti numele tau</h2>
          <input
            placeholder="Numele Personal"
            value={user.name}
            onChange={(e) => setUser({ ...user, name: e.target.value })}
            style={styles.textarea}
          />
          <button
            style={{ ...styles.button, marginTop: 10 }}
            onClick={() => user.name && setEntered(true)}
          >
            Intră în Lumea Virtuala
          </button>
        </div>
      </div>
    );
  }

  return (
    <div style={styles.page}>
      {/* PROFILE */}
      <div style={styles.profile}>
        <img src={user.avatar} alt="avatar" style={styles.avatar} />
        <div>
          <h3>{user.name}</h3>
          <span style={styles.badge}>Activ</span>
        </div>
      </div>

      {/* CREATE POST */}
      <div style={styles.card}>
        <textarea
          placeholder="Ce vrei sa exprimi in ziua aceasta?"
          value={text}
          onChange={(e) => setText(e.target.value)}
          style={styles.textarea}
        />
        {image && <img src={image} alt="preview" style={styles.preview} />}
        <div style={styles.actions}>
          <input type="file" accept="image/*" onChange={handleImage} />
          <button style={styles.button} onClick={addPost}>
            punetim mintea la incercare
          </button>
        </div>
      </div>

      {/* FEED */}
      {posts.map((post) => (
        <div key={post.id} style={styles.post}>
          <div style={styles.postHeader}>
            <img src={post.user.avatar} style={styles.postAvatar} />
            <strong>{post.user.name}</strong>
          </div>
          {post.text && <p>{post.text}</p>}
          {post.image && <img src={post.image} style={styles.postImage} />}
          <button onClick={() => likePost(post.id)} style={styles.like}>
            ❤️ {post.likes}
          </button>
          <CommentSection post={post} onAdd={addComment} />
        </div>
      ))}
    </div>
  );
}

const styles = {
  page: {
    minHeight: "100vh",
    background: "linear-gradient(135deg,#1f2933,#111827)",
    padding: 20,
    fontFamily: "Inter, Arial",
    color: "#fff",
  },
  profile: {
    display: "flex",
    alignItems: "center",
    gap: 12,
    marginBottom: 20,
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: "50%",
  },
  badge: {
    background: "#10b981",
    padding: "2px 8px",
    borderRadius: 999,
    fontSize: 12,
  },
  card: {
    background: "#1f2933",
    padding: 15,
    borderRadius: 16,
    maxWidth: 500,
    marginBottom: 25,
  },
  textarea: {
    width: "100%",
    background: "#111827",
    color: "#fff",
    border: "none",
    borderRadius: 12,
    padding: 12,
  },
  actions: {
    display: "flex",
    justifyContent: "space-between",
    marginTop: 10,
  },
  button: {
    background: "#6366f1",
    color: "#fff",
    border: "none",
    padding: "8px 16px",
    borderRadius: 999,
    cursor: "pointer",
  },
  preview: {
    width: "100%",
    borderRadius: 12,
    marginTop: 10,
  },
  post: {
    background: "#1f2933",
    padding: 15,
    borderRadius: 16,
    maxWidth: 500,
    marginBottom: 20,
  },
  postHeader: {
    display: "flex",
    alignItems: "center",
    gap: 10,
    marginBottom: 10,
  },
  postAvatar: {
    width: 35,
    height: 35,
    borderRadius: "50%",
  },
  postImage: {
    width: "100%",
    borderRadius: 14,
    marginTop: 10,
  },
  like: {
    background: "transparent",
    border: "none",
    color: "#f87171",
    fontSize: 16,
    marginTop: 8,
    cursor: "pointer",
  },
};
